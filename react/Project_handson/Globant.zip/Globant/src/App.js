import React, { Component } from 'react';
import { BrowserRouter , Route} from 'react-router-dom';
import HireList from './containers/HireList';
import Add from './components/Add';


class App extends Component {
  render () {
    return (
      // <BrowserRouter basename="/my-app"> 
      <BrowserRouter>
        <div className="App">
          <HireList />
          <Route path='/add' exact Component={Add} />
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
