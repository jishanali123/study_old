import React from 'react';

const add = (props) => {
    return (
        <h1>ADD </h1>
    );
}

export default add;